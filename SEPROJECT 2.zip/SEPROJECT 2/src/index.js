const express = require("express");
const app = express();
const path = require("path");
const hbs = require("hbs");
// const mongoose = require("mongoose");
// const Login = require("./mongodb")

const staticpath = path.join(__dirname,"../public/template");
const partialpath = path.join(__dirname,"../public/partials");
app.use(express.static(staticpath));
app.use(express.json());
app.set("view engine","hbs");
app.set('views',staticpath);
app.use(express.urlencoded({extended:false}));
// app.set("views",viewPath)
hbs.registerPartials(partialpath);

// mongoose.connect("mongodb://localhost:27017/seproject", { useNewUrlParser: true })
//     .then(() => {
//         console.log("MongoDB connected");
//     })
//     .catch((err) => {
//         console.error("MongoDB connection error: ", err);
//     });


app.get("/",function(req,res)
{
    res.render("main")
});
app.get("/admin",function(req,res)
{
    res.render("admin")
});
app.get("/student",function(req,res)
{
    res.render("student")
});

app.get("/student_register",function(req,res)
{
    res.render("student_register")
});

app.get("/admin_register",function(req,res)
{
    res.render("admin_register")
});

app.get("/s_dashboard",function(req,res)
{
    res.render("s_dashboard")
});
app.get("/student_forgotpw",function(req,res)
{
    res.render("student_forgotpw")
});
app.get("/admin_forgotpw",function(req,res)
{
    res.render("admin_forgotpw")
});
app.get("/a_dashboard",function(req,res)
{
    res.render("a_dashboard")
});
app.get("/s_projects",function(req,res)
{
    res.render("s_projects")
});
app.get("/testing",function(req,res)
{
    res.render("testing")
});
app.get("/web_dev",function(req,res)
{
    res.render("web_dev")
});
app.get("/ai_ml",function(req,res)
{
    res.render("ai_ml")
});
app.get("/app_dev",function(req,res)
{
    res.render("app_dev")
});
// app.post("/admin",async (req,res)=>
// {
// const data ={
//    email:req.body.email,
//    password:req.body.password
// }
// await Login.insertMany([data]);
// res.render("adminlogged");
// })
app.listen(3000,function()
{
    console.log("server listening");
});
